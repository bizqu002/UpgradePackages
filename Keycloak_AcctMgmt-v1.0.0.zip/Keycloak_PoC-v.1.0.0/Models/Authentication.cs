﻿using System;

namespace WpfClient.Models
{
    class Authentication
    {
        public string AccessToken { get; set; }
        
        public int AccessTokenExpiresInSeconds { get; set; }
        
        public string RefreshToken { get; set; }
        
        public int RefreshTokenExpiresInSeconds { get; set; }
        
        public string TokenType { get; set; }
        
        public DateTime NotBeforePolicy { get; set; }
        
        public string SessionState { get; set; }
        
        public string Scope { get; set; }

    }
}

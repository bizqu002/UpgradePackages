﻿using System;
using System.Collections.Generic;

namespace WpfClient.Models
{
    class User
    {
        public string Id { get; set; }

        public DateTime CreatedTimestamp { get; set; }

        public string Username { get; set; }

        public bool Enabled { get; set; }

        public bool Totp { get; set; }

        public bool EmailVerified { get; set; }
    
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string DisableableCredentialTypes { get; set; }

        public string RequiredActions { get; set; }

        public DateTime NotBefore { get; set; }

        public Dictionary<string, bool> Access { get; set; }

    }
}

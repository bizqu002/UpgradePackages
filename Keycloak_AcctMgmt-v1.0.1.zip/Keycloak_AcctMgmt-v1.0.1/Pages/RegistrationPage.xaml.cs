﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using WpfClient.Models;
using WpfClient.Operations;

namespace WpfClient.Pages
{

    public partial class RegistrationPage : Page
    {
        public RegistrationPage()
        {
            InitializeComponent();
        }

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            string username = tbxUsername.Text;
            string firstname = tbxFirstname.Text;
            string lastname = tbxLastname.Text;
            string email = tbxEmail.Text;
            string password = tbxPassword.Password;
            ComboBoxItem roleBox = (ComboBoxItem) tbxRole.SelectedItem;
            string role = roleBox.Content.ToString().ToLower().Replace(" ", "-");

            if (username != "" && firstname != "" && lastname != "" && email != "" && password != "")
            {
                ApiOperations ops = new ApiOperations();
                User user = ops.RegisterUser(username, firstname, lastname, email, password, role);
                if (user == null)
                {
                    MessageBox.Show("This account already exists");
                    return;
                }

                Globals.LoggedInUser = user;
                MessageBox.Show("Your account has been successfuly created");
                NavigationService.Navigate(new DetailsPage());
            }
            else {
                MessageBox.Show("Please fill all the entries in this form");
                return;
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
﻿using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using WpfClient.Models;
using WpfClient.Operations;
using DevExpress.Utils.CommonDialogs.Internal;

namespace WpfClient.Pages
{
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
            CleanUpDirectory(@"C:\Users\bizquierdo\source\repos\RemoteSoftwareUpgrades\Keycloak_AcctMgmt\bin\Debug\net5.0-windows");
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = tbxUsername.Text;
            string password = pbxPassword.Password;

            ApiOperations ops = new ApiOperations();
            User user = ops.AuthenticateUser(username, password);
            if (user == null)
            {
                MessageBox.Show("Invalid username or password");
                return;
            }

            Globals.LoggedInUser = user;
            MessageBox.Show("Login successful");
            NavigationService.Navigate(new DetailsPage());

            CheckForNewUpdates();
        }

        private string GetLatestUpdateLogFile(string filePath)
        {
            DirectoryInfo directory = new DirectoryInfo(filePath);
            string logFileName = directory.GetFiles().OrderByDescending(f => f.LastWriteTime).First().FullName;
            string logFileContents = File.ReadAllText(logFileName);

            return logFileContents;
        }


        private int GetNumericVersion(string verName)
        {
            string version = new String(verName.Where(Char.IsDigit).ToArray());
            int numVersion = Int16.Parse(version);

            return numVersion;
        }

        private void DownloadNewFiles(string downloadLink, string updatePkgName)
        {
            WebClient wb = new WebClient();
            wb.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.33 Safari/537.36");
            wb.DownloadFile(downloadLink, "C:\\Users\\bizquierdo\\Downloads\\" + updatePkgName);

        }

        private void ExtractNewFiles(string updatePkgName)
        {
            string destDir = Regex.Replace(updatePkgName, ".zip", "");
            ZipFile.ExtractToDirectory("C:\\Users\\bizquierdo\\Downloads\\" + updatePkgName, "C:\\Users\\bizquierdo\\Downloads\\" + destDir);
        }

        private void FileRenamerUtility(FileInfo[] files)
        {
            foreach (FileInfo file in files)
            {
                string newFileFullName = Regex.Replace(file.FullName, file.Name, "bkup-" + file.Name);
                File.Move(file.FullName, newFileFullName);
            }
        }
        private void RenameCurrentBinaries(string dirPath)
        {
            DirectoryInfo dir = new DirectoryInfo(dirPath);
            FileInfo[] allFiles = dir.GetFiles();
            FileRenamerUtility(allFiles);
        }

        private void StartUpgrade(string logFileContents, string updatePkgName)
        {
            int startIndex = logFileContents.LastIndexOf("Source Code: ") + "Source Code: ".Length;
            int endIndex = logFileContents.LastIndexOf(".zip") + ".zip".Length;
            string downloadLink = logFileContents.Substring(startIndex, endIndex - startIndex);

            DownloadNewFiles(downloadLink, updatePkgName);

            ExtractNewFiles(updatePkgName);

            RenameCurrentBinaries(@"C:\Users\bizquierdo\source\repos\RemoteSoftwareUpgrades\Keycloak_AcctMgmt");

            RenameCurrentBinaries(@"C:\Users\bizquierdo\source\repos\RemoteSoftwareUpgrades\Keycloak_AcctMgmt\bin\Debug\net5.0-windows");
        }

        private void CheckForNewUpdates()
        {
            string updatesLogPath = "C:\\Users\\bizquierdo\\source\\repos\\RemoteSoftwareUpgrades\\WindowsService\\bin\\Debug\\Logs";

            if (Directory.Exists(updatesLogPath))
            {
                string logFileContents = GetLatestUpdateLogFile(updatesLogPath);
                int startIndex = logFileContents.LastIndexOf("New Upgrade Available:") + "New Upgrade Availble:".Length + 2;
                string updatePkgName = logFileContents.Substring(startIndex, 28);
                updatePkgName = Regex.Replace(updatePkgName, " ", "");

                int updateNumVer = GetNumericVersion(updatePkgName);

                string currentVersion = File.ReadAllText("C:\\Users\\bizquierdo\\source\\repos\\RemoteSoftwareUpgrades\\Keycloak_AcctMgmt\\version");
                int currentNumVer = GetNumericVersion(currentVersion);

                if (updateNumVer > currentNumVer)
                {
                    DialogResult result = (DialogResult)MessageBox.Show("The system has detected an available upgrade. Would you like to install it now?", "Upgrade Available", MessageBoxButton.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        StartUpgrade(logFileContents, updatePkgName);

                        MessageBox.Show("Upgrade has been completed. Click OK to restart application.");

                        Application.Current.Shutdown();

                        LoadUpdates("C:\\Users\\bizquierdo\\Downloads\\Keycloak_AcctMgmt-v1.0.1\\Keycloak_AcctMgmt-v1.0.1",
                                       "C:\\Users\\bizquierdo\\source\\repos\\RemoteSoftwareUpgrades\\Keycloak_AcctMgmt");

                        CleanUpDirectory(@"C:\Users\bizquierdo\source\repos\RemoteSoftwareUpgrades\Keycloak_AcctMgmt");

						RemoveTempDirectories("C:\\Users\\bizquierdo\\Downloads\\Keycloak_AcctMgmt-v1.0.1");
                        
						RemoveTempFiles("C:\\Users\\bizquierdo\\Downloads\\Keycloak_AcctMgmt-v1.0.1.zip");																				
                    }
                }
            }
        }

		private void RemoveTempDirectories(string dirPath)
        {
            if (Directory.Exists(dirPath))
            {
                Directory.Delete(dirPath, true);
            }
        }

        private void RemoveTempFiles(string filePath)
        {
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }
		
        private void CleanUpDirectory(string dirPath)
        {
            DirectoryInfo directory = new DirectoryInfo(dirPath);

            foreach (FileInfo file in directory.GetFiles())
            {
                if (file.FullName.Contains("bkup"))
                {
                    File.SetAttributes(file.FullName, FileAttributes.Normal);
                    File.Delete(file.FullName);
                }

            }
        }

        private string CreateObjectDestPath(string destDirectory, string dirName)
        {
            return Path.Combine(destDirectory, dirName);
        }

        private void LoadDirUpdates(string[] subDirs, string destParentDir)
        {
            foreach (string directory in subDirs)
            {
                string directoryName = Path.GetFileName(directory);

                string directoryPath = CreateObjectDestPath(destParentDir, directoryName);

                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                LoadUpdates(directory, directoryPath);
            }
        }

        private void LoadSingleFileUpdates(string[] allFiles, string destDirectory)
        {
            foreach (var file in allFiles)
            {
                string fileName = Path.GetFileName(file);

                string filePath = CreateObjectDestPath(destDirectory, fileName);

                if (File.Exists(filePath))
                {
                    File.SetAttributes(filePath, FileAttributes.Normal);
                    File.Delete(filePath);
                }

                File.Copy(file, filePath, true);
            }
        }

        private void LoadUpdates(string rootDirectory, string destDirectory)
        {
            string[] subDirectories = Directory.GetDirectories(rootDirectory);

            LoadDirUpdates(subDirectories, destDirectory);

            string[] allFiles = Directory.GetFiles(rootDirectory);

            LoadSingleFileUpdates(allFiles, destDirectory);
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RegistrationPage());
        }
    }
}



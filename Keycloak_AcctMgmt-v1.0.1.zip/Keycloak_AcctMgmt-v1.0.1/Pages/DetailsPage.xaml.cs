﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;


namespace WpfClient.Pages
{
    public partial class DetailsPage : Page
    {
        public DetailsPage()
        {
            InitializeComponent();
        }

        private void detailsPage_Loaded(object sender, RoutedEventArgs e)
        {
            ShowUserInfo();
        }

        private void ShowUserInfo()
        {
            tbkUsername.Text = Globals.LoggedInUser.Username;
            tbkCreated.Text = Globals.LoggedInUser.CreatedTimestamp.ToString();
            tbkFname.Text = Globals.LoggedInUser.FirstName;
            tbkLname.Text = Globals.LoggedInUser.LastName;
            tbkEmail.Text = Globals.LoggedInUser.Email;
            tbkEnabled.Text = Globals.LoggedInUser.Enabled.ToString();
            tbkVerified.Text = Globals.LoggedInUser.EmailVerified.ToString();
            
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            Globals.LoggedInUser = null;
            NavigationService.Navigate(new LoginPage());
        }
    }
}
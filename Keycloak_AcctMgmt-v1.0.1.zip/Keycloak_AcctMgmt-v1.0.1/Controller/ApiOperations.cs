﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using WpfClient.Models;
using WpfClient.Controller;
using System.IO;
using System.Text.RegularExpressions;

namespace WpfClient.Operations
{
    class ApiOperations
    {
        private PayloadProcessor processor;

        private string baseUrl;

        private string realm;

        private string client;

        private string clientSecret;

        public ApiOperations()
        {
            baseUrl = "http://localhost:8080/";
            clientSecret = "20c5788e-3862-4f02-9d94-2ddc98f7dac9";
            realm = "demo";
            client = "mvcdmo";

            processor = new PayloadProcessor();
        }

        public WebRequest HttpRequestGetAllUsersData(string accessToken, string requestUrl)
        {
            WebRequest webRequest = WebRequest.Create(requestUrl);
            webRequest.Method = "GET";
            webRequest.Headers.Add("Authorization", "Bearer " + accessToken);

            return webRequest;
        }

        public string HttpResponseGetAllUsersData(WebRequest webRequest)
        {
            WebResponse webResponse = webRequest.GetResponse();

            char[] charsToTrim = { '[', '{', '}', ']' };

            string payload = new StreamReader(webResponse.GetResponseStream()).ReadToEnd().Trim(charsToTrim);

            return payload;

        }

        public List<User> GetAllUsersInRealm(string accessToken)
        {
            List<User> allUsers = new List<User>();

            string requestUrl = this.baseUrl + "auth/admin/realms/" + realm + "/users";

            WebRequest webRequest = HttpRequestGetAllUsersData(accessToken, requestUrl);

            try
            {
                string allUsersRawPayload = HttpResponseGetAllUsersData(webRequest);

                allUsersRawPayload = Regex.Replace(allUsersRawPayload, "[}\"]", "").Replace(":{", "");

                List<string> allUsersPayload = allUsersRawPayload.Split(",{").ToList();

                foreach (string user in allUsersPayload)
                {
                    Dictionary<string, string> userPayload = processor.ToDictionary(user);
                    User individualUser = processor.PayloadProcessingForUserData(userPayload);
                    allUsers.Add(individualUser);
                }
            }
            catch (Exception) 
            {
                return null;
            }

            return allUsers;
        }

        public WebRequest HttpRequestAccessData(string requestUrl, byte[] requestBody)
        {
            WebRequest webRequest = WebRequest.Create(requestUrl);
            webRequest.Method = "POST";
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.ContentLength = requestBody.Length;

            return webRequest;

        }

        public byte[] HttpBodyRequestEncoding(string body)
        {
            ASCIIEncoding encoder = new ASCIIEncoding();
            byte[] requestBody = encoder.GetBytes(body);

            return requestBody;
        }

        public void HttpRequestStreamer(WebRequest webRequest, byte[] requestBody)
        {
            Stream webRequestStream = webRequest.GetRequestStream();
            webRequestStream.Write(requestBody, 0, requestBody.Length);
            webRequestStream.Close();
        }

        public string HttpResponseAccessData(WebRequest webRequest)
        {
            WebResponse webResponse = webRequest.GetResponse();

            string payload = new StreamReader(webResponse.GetResponseStream()).ReadToEnd();
            payload = Regex.Replace(payload, "[{}\"]", "");

            return payload;
        }

        public Authentication GetUserAccessData(string requestBody)
        {
            string requestUrl = this.baseUrl + "auth/realms/" + realm + "/protocol/openid-connect/token";

            byte[] requestEncBody = HttpBodyRequestEncoding(requestBody);

            WebRequest webRequest = HttpRequestAccessData(requestUrl, requestEncBody);

            HttpRequestStreamer(webRequest, requestEncBody);

            try
            {
                string rawUserPayload = HttpResponseAccessData(webRequest);
                Dictionary<string, string> userPayload = processor.ToDictionary(rawUserPayload);
                Authentication auth = processor.PayloadProcessingForAuthentication(userPayload);

                return auth;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public User AuthenticateUser(string username, string password)
        {
           string requestBody = "grant_type=password" +
                                 "&client_id=" + client +
                                 "&client_secret=" + clientSecret + 
                                 "&username=" + username +
                                 "&password=" + password;

            Authentication auth = GetUserAccessData(requestBody);
            
            if (auth == null)
            {
                return null;
            }
            else
            {
                User user = GetUserDetails(username);

                return user;
            }
        }

        public User GetUserDetails(string username)
        {
            string genericRequestBody = GenericAccessRequestBody();

            Authentication genericAuth = GetUserAccessData(genericRequestBody);

            string genericAccessToken = genericAuth.AccessToken;

            List<User> allUsers = GetAllUsersInRealm(genericAccessToken);

            User user = allUsers.Find(e => e.Username == username);

            return user;
        }

        public WebRequest HttpRequestRegisterUser(string requestUrl, string userAccessToken, string requestBody) 
        {
            WebRequest webRequest = WebRequest.Create(requestUrl);

            webRequest.Method = "POST";
            webRequest.Headers.Add("Authorization", "Bearer " + userAccessToken);
            webRequest.ContentType = "application/json";

            using (StreamWriter streamWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                streamWriter.Write(requestBody);
            }

            return webRequest;
        }

        public string GenericAccessRequestBody()
        {
            string requestBody ="grant_type=password" +
                                "&client_id=" + client +
                                "&client_secret=" + clientSecret +
                                "&username=admin" + //make sure this user exists
                                "&password=admin";

            return requestBody;
        }

        public User RegisterUser(string username, string firstName, string lastName, string email, string password, string role)
        {
            User user = new User();

            string request = GenericAccessRequestBody();

            string userAccessToken = GetUserAccessData(request).AccessToken;            

            string requestUrl = this.baseUrl + "auth/admin/realms/" + realm + "/users";

            string requestBody = "{\"firstName\":\"" + firstName + "\"," +
                                 "\"lastName\":\"" + lastName + "\"," +
                                 "\"email\":\"" + email + "\"," +
                                 "\"enabled\":\"true\"," +
                                 "\"emailVerified\":\"true\"," +
                                 "\"credentials\":[{\"type\":\"password\", \"value\":\"" + password + "\", \"temporary\": false}]," +
                                 "\"groups\":[\"" + role + "\"]," +
                                 "\"username\":\"" + username + "\"}";

            string dada = requestBody.ToLower();

            WebRequest webRequest = HttpRequestRegisterUser(requestUrl, userAccessToken, requestBody);

            try
            {
                WebResponse webResponse = webRequest.GetResponse();

                user = GetUserDetails(username);
                    
                return user;
            }
            catch (Exception)
            {
                return null;
            }
        }
        
    }
}
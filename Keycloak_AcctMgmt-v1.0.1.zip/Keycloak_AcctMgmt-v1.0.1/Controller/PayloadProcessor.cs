﻿using System;
using System.Collections.Generic;
using System.Linq;
using WpfClient.Models;

namespace WpfClient.Controller
{
    class PayloadProcessor
    {

        public DateTime nbfDateCalculator(string numericDate)
        {

            DateTime notBeforePolicy = new DateTime(1970, 1, 1);

            notBeforePolicy.AddSeconds(double.Parse(numericDate));

            return notBeforePolicy;
        }

        public DateTime numericTimestampTranslator(string numericTimestamp)
        {

            DateTime createdDate = new DateTime(1970, 1, 1);

            createdDate = createdDate.AddMilliseconds(double.Parse(numericTimestamp)).ToLocalTime();

            return createdDate;
        }

        public User PayloadProcessingForUserData(Dictionary<string, string> userRawPayload)
        {
            User user = new User();
            user.Id = userRawPayload["id"];
            user.CreatedTimestamp = numericTimestampTranslator(userRawPayload["createdTimestamp"]);
            user.Username = userRawPayload["username"];
            user.Enabled = bool.Parse(userRawPayload["enabled"]);
            user.Totp = bool.Parse(userRawPayload["totp"]);
            user.EmailVerified = bool.Parse(userRawPayload["emailVerified"]);
            user.FirstName = userRawPayload["firstName"];
            user.LastName = userRawPayload["lastName"];
            user.Email = userRawPayload["email"];
            user.DisableableCredentialTypes = userRawPayload["disableableCredentialTypes"];
            user.RequiredActions = userRawPayload["requiredActions"];
            user.NotBefore = nbfDateCalculator(userRawPayload["notBefore"]);

            Dictionary<string, bool> accessDetails = new Dictionary<string, bool>();
            accessDetails.Add("ManageGroupMembership", bool.Parse(userRawPayload["accessmanageGroupMembership"]));
            accessDetails.Add("View", bool.Parse(userRawPayload["view"]));
            accessDetails.Add("MapRoles", bool.Parse(userRawPayload["mapRoles"]));
            accessDetails.Add("Impersonate", bool.Parse(userRawPayload["impersonate"]));
            accessDetails.Add("Manage", bool.Parse(userRawPayload["manage"]));

            user.Access = accessDetails;

            return user;

        }

        public Authentication PayloadProcessingForAuthentication(Dictionary<string, string> userPayload) 
        {
            Authentication auth = new Authentication();
            auth.AccessToken = userPayload["access_token"];
            auth.AccessTokenExpiresInSeconds = Int32.Parse(userPayload["expires_in"]);
            auth.RefreshToken = userPayload["refresh_token"];
            auth.RefreshTokenExpiresInSeconds = Int32.Parse(userPayload["refresh_expires_in"]);
            auth.TokenType = userPayload["token_type"];
            auth.SessionState = userPayload["session_state"];
            auth.Scope = userPayload["scope"];
            auth.NotBeforePolicy = nbfDateCalculator(userPayload["not-before-policy"]);

            return auth;

        }

        public Dictionary<string, string> ToDictionary(string payload) 
        {
            Dictionary<string, string> payloadInDic = payload.Split(new[] {','}, StringSplitOptions.RemoveEmptyEntries).Select(part => part.Split(':')).ToDictionary(split => split[0], split => split[1]);

            return payloadInDic;
        }

    }
}
